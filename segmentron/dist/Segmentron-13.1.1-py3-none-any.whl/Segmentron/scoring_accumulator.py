#Basic accumulation function that adds together scores
def addition_function(a, b):
    return a + b